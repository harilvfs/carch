This bash script are in developement Phase. Bugs may be expected. Working in it :)
